<a className="gh-badge" href="https://datahub.io/core/geo-boundaries-world-110m"><img src="https://badgen.net/badge/icon/View%20on%20datahub.io/orange?icon=https://datahub.io/datahub-cube-badge-icon.svg&label&scale=1.25" alt="badge" /></a>

# DEPRECATED
Please use the newer and better maintained datapackage https://github.com/datasets/geo-countries

## Data
Geodata data package providing geojson polygons for all the world's countries.
Perfect for use in apps and visualizations.

